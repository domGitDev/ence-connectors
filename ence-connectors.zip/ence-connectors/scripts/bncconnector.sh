killall -r connector
cd ..
nohup ./connector -t bncbook -d obook5 -e binance -f 1 &
nohup ./connector -t bncprice -d price -e binance -f 1 &
nohup ./connector -t bncbook -d orders -e binance -f 1 -o 1 -v 2 &

