killall -r connector
cd ..
nohup ./connector -t okxbook -d obook -e okex -f 1 &
nohup ./connector_mysql -t okxprice -d price -e okex -f 1 -v 1 & 
nohup ./connector -t okxbook -d orders -e okex -f 1 -v 2 &
