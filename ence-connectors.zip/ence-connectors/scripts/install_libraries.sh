#!/bin/sh

# BUILD CMAKE 2.8

wget https://cmake.org/files/v3.12/cmake-3.12.0.tar.gz

tar xzf cmake-3.12.0.tar.gz

cd cmake-3.12.0

./configure

make -j 8

make install

cd ..


# BUILD OPENSSL

wget https://www.openssl.org/source/openssl-1.1.1g.tar.gz

tar -xf openssl-1.1.1g.tar.gz

mkdir -p /usr/local/openssl-1.1.1g

cd openssl-1.1.1g

./config --prefix=/usr/local/openssl-1.1.1g --openssldir=/usr/local/openssl-1.1.1g shared zlib

make

make install

ln -sf /usr/local/openssl-1.1.1g /usr/local/openssl

export PATH=/usr/local/openssl-1.1.1g/bin:$PATH

export OPENSSL_ROOT_DIR=/usr/local/openssl-1.1.1g

export LD_LIBRARY_PATH=/usr/local/openssl/lib:$LD_LIBRARY_PATH

cd ..

# BUILD BOOST

wget https://dl.bintray.com/boostorg/release/1.69.0/source/boost_1_69_0.tar.gz

tar -xzf boost_1_69_0.tar.gz

mkdir -p /usr/local/boost_1_69_0

cd boost_1_69_0

./bootstrap.sh --prefix=/usr/local/boost-1.69.0

./b2 install --prefix=/usr/local/boost-1.69.0 --without-python

ln -sf /usr/local/boost-1.69.0 /usr/local/boost

export PATH=/usr/local/boost-1.69.0/bin:$PATH

cd ..

# LIBWEBSOCKETS

git clone https://github.com/warmcat/libwebsockets.git

mkdir -p /usr/local/libwebsockets

cd libwebsockets

git checkout v4.1.0-rc2

mkdir build && cd build

cmake .. -DCMAKE_INSTALL_PREFIX=/usr/local/libwebsockets -DLWS_WITH_HTTP2=1 -DLWS_OPENSSL_INCLUDE_DIRS=/usr/local/openssl-1.1.1g/include -DLWS_OPENSSL_LIBRARIES="/usr/local/openssl-1.1.1g/lib/libssl.so;/usr/local/openssl-1.1.1g/lib/libcrypto.so"

make -j 4

make install

ln -sf /usr/local/libwebsockets-4.1.0 /usr/local/libwebsockets

cd ..
cd ..

# BUILD LIBRDKAFKA (https://github.com/edenhill/librdkafka)

git clone https://github.com/edenhill/librdkafka.git

cd librdkafka

git checkout v1.5.0

mkdir -p /usr/local/librdkafka-1.5.0

cmake -H. -B_cmake_build -DOPENSSL_ROOT_DIR=/usr/local/openssl-1.1.1g -DCMAKE_INSTALL_PREFIX=/usr/local/librdkafka-1.5.0

cmake --build _cmake_build --target install

rm -rf _cmake_build

cmake -H. -B_cmake_build -DOPENSSL_ROOT_DIR=/usr/local/openssl-1.1.1g -DCMAKE_INSTALL_PREFIX=/usr/local/librdkafka-1.5.0 -DRDKAFKA_BUILD_STATIC=1

cmake --build _cmake_build --target install

ln -sf /usr/local/librdkafka-1.5.0 /usr/local/librdkafka

cd ..

# BUILD CPPKAFKA (https://github.com/mfontanini/cppkafka)

git clone https://github.com/mfontanini/cppkafka.git

cd cppkafka

git checkout v0.3.1

mkdir -p /usr/local/cppkafka-0.3.1

mkdir build && cd build

cmake -DRDKAFKA_INCLUDE_DIR=/usr/local/librdkafka-1.5.0/include -DRDKAFKA_LIBRARY=/usr/local/librdkafka-1.5.0/lib64/librdkafka.a -DBoost_INCLUDE_DIR=/usr/local/boost/include -DBoost_LIBRARY_DIR=/usr/local/boost/lib -DCPPKAFKA_BUILD_SHARED=ON -DCMAKE_INSTALL_PREFIX=/usr/local/cppkafka-0.3.1 ..

make -j 6

make install

ln -sf /usr/local/cppkafka-0.3.1 /usr/local/cppkafka

cd ..
cd ..

# BUILD CURL

wget https://curl.haxx.se/download/curl-7.68.0.tar.gz

gunzip -c curl-7.68.0.tar.gz | tar xvf -

mkdir -p /usr/local/curl-7.68.0

cd curl-7.68.0

./configure --with-ssl=/usr/local/openssl-1.1.1g/bin/openssl --prefix=/usr/local/curl-7.68.0

make -j 6

make install

ln -sf /usr/local/curl-7.68.0 /usr/local/curl

export PATH=/usr/local/curl/bin:$PATH

cd ..

# BUILD CPR (https://github.com/whoshuu/cpr)

git clone https://github.com/whoshuu/cpr.git

mkdir -p /usr/local/cpr-1.4.0

cd cpr

git checkout 1.4.0

git submodule update --init --recursive

mkdir build && cd build

cmake -DOPENSSL_INCLUDE_DIR=/usr/local/openssl-1.1.1g/include \
    -DOPENSSL_LIBRARIES="libssl.so;libcrypto.so" \
    -DCMAKE_INSTALL_PREFIX=/usr/local/cpr-1.4.0 \
    -DCURL_INCLUDE_DIRS="/usr/local/curl-7.68.0/include;/usr/local/curl-7.68.0/include/curl" \
    -DCURL_LIBRARIES="libcurl.so" -DBUILD_SHARED_LIBS=ON -DUSE_SYSTEM_CURL=ON ..

make -j 8

make install

ln -sf /usr/local/cpr-1.4.0 /usr/local/cpr

cd .. 
cd ..


# Build JSONCPP

wget https://github.com/open-source-parsers/jsoncpp/archive/1.8.3.tar.gz

mv 1.8.3.tar.gz jsoncpp-1.8.3.tar.gz

tar -xzf jsoncpp-1.8.3.tar.gz

mkdir -p /usr/local/jsoncpp-1.8.3

cd jsoncpp-1.8.3

mkdir build && cd build

cmake -DCMAKE_INSTALL_PREFIX=/usr/local/jsoncpp-1.8.3 -DBUILD_SHARED_LIBS=ON ..

make install

ln -sf /usr/local/jsoncpp-1.8.3 /usr/local/jsoncpp
